// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Kelsey Wyer

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <string>
#include <tuple>

// Global structures and variables
typedef struct standard_types {
    std::string name;
    long long min{};
    long long max{};
} type;

type types[14];

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns> tuple
template <typename T>
std::tuple<unsigned long int, bool> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    std::string type_name = typeid(T).name();
    bool overflow = false;
    bool found = false;
    std::tuple<unsigned long int, bool> results;
    unsigned int i;
    unsigned int j;
    
    // Check each standard data type for a match
    for (i = 0; i <= sizeof(types); ++i) {
        if (types[i].name == type_name) {
            found = true;

            // Heart of the overflow test
            for (j = 0; j < steps; ++j) {
                if (result > (types[i].max - increment)) {
                    overflow = true;
                }
                else {
                    result += increment;
                }
            }
        }

    }
    // If matching type not found
    if (!found) {
        if (type_name == "float") {

            for (i = 0; i < steps; ++i) {
                if (result > (FLT_MAX - increment)) {    // float overflow detection
                    overflow = true;
                }
                else {
                    result += increment;
                }
            }

        }
        else if (type_name == "double") {

            for (i = 0; i < steps; ++i) {
                if (result > (DBL_MAX - increment)) {    // double overflow detection
                    overflow = true;
                }
                else {
                    result += increment;
                }
            }

        }
        else if (type_name == "long double") {

            for (i = 0; i < steps; ++i) {
                if (result > (LDBL_MAX - increment)) {    // long double overflow detection
                    overflow = true;
                }
                else {
                    result += increment;
                }
            }

        }
    }

    /* Return a tuple with the final sum and overflow boolean.
    * Using a tuple allows the function to return 2 values */

    results = std::make_tuple(result, overflow);
    return results;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>start - (increment * steps)</returns>

template <typename T>
std::tuple<unsigned long int, bool> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    std::string type_name = typeid(T).name();
    bool underflow = false;
    bool found = false;
    std::tuple<unsigned long int, bool> results;
    int total_types = 14;
    unsigned int i;
    unsigned int j;

    // Check each of the standard types from the types array
    for (i = 0; i <= sizeof(types); ++i) {
        if (types[i].name == type_name) {
            found = true;
            
            // Heart of underflow detection
            for (j = 0; j < steps; ++j) {
                if (result < (types[i].min + decrement)) {
                    underflow = true;
                }
                else {
                    result -= decrement;
                }
            }
        }
    }
    // If matching type not found in array, look further
    if (!found) {
        if (type_name == "float") {

            for (i = 0; i < steps; ++i) {
                if (result < (FLT_MIN + decrement)) {    // float underflow detection
                    underflow = true;
                }
                else {
                    result -= decrement;
                }
            }
        }
        else if (type_name == "double") {
            for (i = 0; i < steps; ++i) {
                if (result < (DBL_MIN + decrement)) {    // double underflow detection
                    underflow = true;
                }
                else {
                    result -= decrement;
                }
            }

        }
        else if (type_name == "long double") {
            for (i = 0; i < steps; ++i) {
                if (result < (LDBL_MIN + decrement)) {    // long double underflow detection
                    underflow = true;
                }
                else {
                    result -= decrement;
                }
            }

        }
    }

    // Return a tuple consisting of both the difference and underflow boolean
    results = std::make_tuple(result, underflow);
    return results;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    unsigned long sum;
    bool OF_status;
    std::tuple<unsigned long, bool> OF_results;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    OF_results = add_numbers<T>(start, increment, steps);

    // Unpacks the returned tuple into variables 
    std::tie(sum, OF_status) = OF_results;
    if (OF_status) {
        std::cout << "Final sum = " << sum << " Overflow caught." << std::endl;
    }
    else {
        std::cout << "Final sum = " << sum << " No overflow." << std::endl;

    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    OF_results = add_numbers<T>(start, increment, steps + 1);

    // Unpacks the returned tuple into variables 
    std::tie(sum, OF_status) = OF_results;
    if (OF_status) {
        std::cout << "Final sum = " << sum << " Overflow caught." << std::endl;
    }
    else {
        std::cout << "Final sum = " << sum << " No overflow." << std::endl;

    }


}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    unsigned long diff;
    bool UF_status;
    std::tuple<unsigned long, bool> UF_results;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    UF_results = subtract_numbers<T>(start, decrement, steps);

    // Unpacks the returned tuple into variables 
    std::tie(diff, UF_status) = UF_results;

    if (UF_status) {
        std::cout << "Final difference = " << diff << " Underflow caught." << std::endl;
    }
    else {
        std::cout << "Final difference = " << diff << " No underflow." << std::endl;

    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    UF_results = subtract_numbers<T>(start, decrement, steps + 1);

    // Unpacks the returned tuple into variables 
    std::tie(diff, UF_status) = UF_results;

    if (UF_status) {
        std::cout << "Final difference = " << diff << " Underflow caught." << std::endl;
    }
    else {
        std::cout << "Final difference = " << diff << " No underflow." << std::endl;

    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

void fill_min_max_array() {

    // signed types
    types[0].name = "char";
    types[0].min = SCHAR_MIN;
    types[0].max = SCHAR_MAX;

    types[1].name = "wchar_t";
    types[1].min = WCHAR_MIN;
    types[1].max = WCHAR_MAX;

    types[2].name = "short";
    types[2].min = SHRT_MIN;
    types[2].max = SHRT_MAX;

    types[3].name = "int";
    types[3].min = INT_MIN;
    types[3].max = INT_MAX;

    types[4].name = "long";
    types[4].min = LONG_MIN;
    types[4].max = LONG_MAX;

    types[5].name = "__int64";
    types[5].min = LLONG_MIN;
    types[5].max = LLONG_MAX;

    // unsigned types
    types[6].name = "unsigned char";
    types[6].min = 0;
    types[6].max = UCHAR_MAX;

    types[7].name = "unsigned short";
    types[7].min = 0;
    types[7].max = USHRT_MAX;

    types[8].name = "unsigned int";
    types[8].min = 0;
    types[8].max = UINT_MAX;

    types[9].name = "unsigned long";
    types[9].min = 0;
    types[9].max = ULONG_MAX;

    types[10].name = "unsigned __int64";
    types[10].min = 0;
    types[10].max = ULLONG_MAX;
                           
}
/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    fill_min_max_array();

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
